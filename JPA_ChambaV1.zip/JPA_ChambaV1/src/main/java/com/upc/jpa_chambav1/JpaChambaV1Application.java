package com.upc.jpa_chambav1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JpaChambaV1Application {

    public static void main(String[] args) {
        SpringApplication.run(JpaChambaV1Application.class, args);
    }

}
