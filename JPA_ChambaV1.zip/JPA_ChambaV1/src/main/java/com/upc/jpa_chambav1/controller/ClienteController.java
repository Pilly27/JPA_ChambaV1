package com.upc.jpa_chambav1.controller;

import com.upc.jpa_chambav1.dtos.ClienteDTO;
import com.upc.jpa_chambav1.entities.Cliente;
import com.upc.jpa_chambav1.services.ClienteService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Arrays;
import java.util.List;

@RestController
@RequestMapping("/api")
public class ClienteController {
    @Autowired
    private ClienteService clienteService;

    @PostMapping("/cliente")
    public ResponseEntity<ClienteDTO> save(@RequestBody ClienteDTO clienteDTO){
        ModelMapper modelMapper = new ModelMapper();
        Cliente cliente = modelMapper.map(clienteDTO, Cliente.class);
        cliente = clienteService.save(cliente);
        clienteDTO = modelMapper.map(cliente, ClienteDTO.class);
        return new ResponseEntity<>(clienteDTO, HttpStatus.OK);
    }

    @PutMapping("/cliente")
    public void modificar(@RequestBody ClienteDTO clienteDTO){
        ModelMapper modelMapper = new ModelMapper();
        Cliente cliente = modelMapper.map(clienteDTO, Cliente.class);
        clienteService.save(cliente);
    }

    @GetMapping("/clientes")
    public ResponseEntity<List<ClienteDTO>> list(){
        ModelMapper modelMapper = new ModelMapper();
        List<ClienteDTO> cli = Arrays.asList(
                modelMapper.map(clienteService.list(),
                        ClienteDTO[].class));
        return new ResponseEntity<>(cli, HttpStatus.OK);
    }

    @DeleteMapping("/cliente/{id}")
    public void eliminar(@PathVariable("id") Long id){
        clienteService.delete(id);
    }

    @GetMapping("/cliente/{id}")
    public ResponseEntity<ClienteDTO> listarId(@PathVariable("id") Long id){
        ModelMapper modelMapper = new ModelMapper();
        ClienteDTO clienteDTO = modelMapper.map(clienteService.listarId(id), ClienteDTO.class);
        return new ResponseEntity<>(clienteDTO, HttpStatus.OK);
    }

}
