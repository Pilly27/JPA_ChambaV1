package com.upc.jpa_chambav1.controller;

import com.upc.jpa_chambav1.dtos.OficioDTO;
import com.upc.jpa_chambav1.entities.Oficio;
import com.upc.jpa_chambav1.services.OficioService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Arrays;
import java.util.List;

@RestController
@RequestMapping("/api")
public class OficioController {
    @Autowired
    private OficioService oficioService;

    @PostMapping("/oficio")
    public ResponseEntity<OficioDTO> save(@RequestBody OficioDTO oficioDTO){
        ModelMapper modelMapper = new ModelMapper();
        Oficio oficio = modelMapper.map(oficioDTO, Oficio.class);
        oficio = oficioService.save(oficio);
        oficioDTO = modelMapper.map(oficio, OficioDTO.class);
        return new ResponseEntity<>(oficioDTO, HttpStatus.OK);
    }
    @GetMapping("/oficios")
    public ResponseEntity<List<OficioDTO>> list(){
        ModelMapper modelMapper = new ModelMapper();
        List<OficioDTO> ofi = Arrays.asList(
                modelMapper.map(oficioService.list(),
                        OficioDTO[].class));
        return new ResponseEntity<>(ofi, HttpStatus.OK);
    }
}
