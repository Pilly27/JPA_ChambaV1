package com.upc.jpa_chambav1.controller;

import com.upc.jpa_chambav1.dtos.PagoDTO;
import com.upc.jpa_chambav1.entities.Pago;
import com.upc.jpa_chambav1.services.PagoService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Arrays;
import java.util.List;

@RestController
@RequestMapping("/api")
public class PagoController {
    @Autowired
    private PagoService pagoService;

    @PostMapping("/pago")
    public ResponseEntity<PagoDTO> save(@RequestBody PagoDTO pagoDTO){
        ModelMapper modelMapper = new ModelMapper();
        Pago pago = modelMapper.map(pagoDTO, Pago.class);
        pago = pagoService.save(pago);
        pagoDTO = modelMapper.map(pago, PagoDTO.class);
        return new ResponseEntity<>(pagoDTO, HttpStatus.OK);
    }

    @GetMapping("/pagos")
    public ResponseEntity<List<PagoDTO>> list(){
        ModelMapper modelMapper = new ModelMapper();
        List<PagoDTO> pag = Arrays.asList(
                modelMapper.map(pagoService.list(),
                        PagoDTO[].class));
        return new ResponseEntity<>(pag, HttpStatus.OK);
    }
}
