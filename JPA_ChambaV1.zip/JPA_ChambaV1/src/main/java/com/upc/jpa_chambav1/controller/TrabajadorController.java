package com.upc.jpa_chambav1.controller;

import com.upc.jpa_chambav1.dtos.TrabajadorDTO;
import com.upc.jpa_chambav1.entities.Trabajador;
import com.upc.jpa_chambav1.services.TrabajadorService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Arrays;
import java.util.List;

@RestController
@RequestMapping("/api")
public class TrabajadorController {
    @Autowired
    private TrabajadorService trabajadorService;

    @PostMapping("/trabajador")
    public ResponseEntity<TrabajadorDTO> save(@RequestBody TrabajadorDTO trabajadorDTO){
        ModelMapper modelMapper = new ModelMapper();
        Trabajador trabajador = modelMapper.map(trabajadorDTO, Trabajador.class);
        trabajador = trabajadorService.save(trabajador);
        trabajadorDTO = modelMapper.map(trabajador, TrabajadorDTO.class);
        return new ResponseEntity<>(trabajadorDTO, HttpStatus.OK);
    }

    @GetMapping("/trabajadores")
    public ResponseEntity<List<TrabajadorDTO>> list(){
        ModelMapper modelMapper = new ModelMapper();
        List<TrabajadorDTO> tra = Arrays.asList(
                modelMapper.map(trabajadorService.list(),
                        TrabajadorDTO[].class));
        return new ResponseEntity<>(tra, HttpStatus.OK);
    }
}
