package com.upc.jpa_chambav1.repositories;

import com.upc.jpa_chambav1.entities.Oficio;
import org.springframework.data.jpa.repository.JpaRepository;

public interface OficioRepository extends JpaRepository<Oficio, Long> {

}
