package com.upc.jpa_chambav1.repositories;

import com.upc.jpa_chambav1.entities.Pago;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PagoRepository extends JpaRepository<Pago, Long> {

}
