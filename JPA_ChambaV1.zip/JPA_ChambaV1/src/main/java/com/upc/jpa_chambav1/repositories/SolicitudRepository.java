package com.upc.jpa_chambav1.repositories;

import com.upc.jpa_chambav1.entities.Solicitud;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SolicitudRepository extends JpaRepository<Solicitud, Long> {

}
