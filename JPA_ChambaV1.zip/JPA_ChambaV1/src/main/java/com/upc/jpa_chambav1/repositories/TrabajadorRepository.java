package com.upc.jpa_chambav1.repositories;

import com.upc.jpa_chambav1.entities.Trabajador;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TrabajadorRepository extends JpaRepository<Trabajador, Long> {

}
