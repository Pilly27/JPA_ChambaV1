package com.upc.jpa_chambav1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JpaChambaV1ApplicationTests {

    @Test
    void contextLoads() {
    }

}
